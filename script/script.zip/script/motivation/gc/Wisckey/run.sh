

/home/ubuntu/CLionProjects/Wisckey-Origin/out-static/db_bench --benchmarks=fillrandom --value_size=128 --num=40000000 --db=/media/test &> 6.txt

/home/ubuntu/CLionProjects/Wisckey-Origin/out-static/db_bench --benchmarks=fillrandom --value_size=128 --num=80000000 --db=/media/test &> 7.txt

/home/ubuntu/CLionProjects/Wisckey-Origin/out-static/db_bench --benchmarks=fillrandom --value_size=128 --num=160000000 --db=/media/test &> 8.txt

/home/ubuntu/CLionProjects/Wisckey-Origin/out-static/db_bench --benchmarks=fillrandom --value_size=128 --num=400000000 --db=/media/test &> 9.txt

/home/ubuntu/CLionProjects/Wisckey-Origin/out-static/db_bench --benchmarks=fillrandom --value_size=128 --num=800000000 --db=/media/test &> 10.txt

