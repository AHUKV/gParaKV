ulimit -n 999999
/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=2 --max_background_compactions=1 --enable_blob_garbage_collection=true &> 0.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=3 --max_background_compactions=2 --enable_blob_garbage_collection=true  &> 1.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=4 --max_background_compactions=3 --enable_blob_garbage_collection=true  &> 2.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=5 --max_background_compactions=4 --enable_blob_garbage_collection=true  &> 3.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=7 --max_background_compactions=6 --enable_blob_garbage_collection=true  &> 4.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=9 --max_background_compactions=8 --enable_blob_garbage_collection=true  &> 5.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=13 --max_background_compactions=12 --enable_blob_garbage_collection=true  &> 6.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=17 --max_background_compactions=16 --enable_blob_garbage_collection=true  &> 7.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=21 --max_background_compactions=20 --enable_blob_garbage_collection=true  &> 8.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=25 --max_background_compactions=24 --enable_blob_garbage_collection=true  &> 9.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=29 --max_background_compactions=28 --enable_blob_garbage_collection=true  &> 10.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=33 --max_background_compactions=32 --enable_blob_garbage_collection=true  &> 11.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=37 --max_background_compactions=36 --enable_blob_garbage_collection=true  &> 12.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=43 --max_background_compactions=42 --enable_blob_garbage_collection=true  &> 13.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=49 --max_background_compactions=48 --enable_blob_garbage_collection=true  &> 14.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=65 --max_background_compactions=64 --enable_blob_garbage_collection=true  &> 15.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=73 --max_background_compactions=72 --enable_blob_garbage_collection=true  &> 16.txt

/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --compression_type=none --benchmarks=fillrandom --num=100000000 --value_size=1024 --histogram=1 --db=/media/test --max_background_jobs=81 --max_background_compactions=80 --enable_blob_garbage_collection=true  &> 17.txt
