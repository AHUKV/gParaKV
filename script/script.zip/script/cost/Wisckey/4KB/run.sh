/home/ubuntu/CLionProjects/Wisckey-Origin/out-static/db_bench --benchmarks=fillrandom --value_size=4096 --num=25000000 --db=/media/test &> 1.txt

