/home/ubuntu/CLionProjects/Wisckey-Origin/out-static/db_bench --benchmarks=fillrandom --value_size=256 --num=400000000 --db=/media/test &> 1.txt

