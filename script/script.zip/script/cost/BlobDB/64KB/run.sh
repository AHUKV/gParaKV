/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --benchmarks=fillrandom --value_size=65536 --num=1562500 --db=/media/test &> 1.txt

