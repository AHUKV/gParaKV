/home/ubuntu/CLionProjects/rocksdb-9.8.4/cmake-build-debug/db_bench --benchmarks=fillrandom --value_size=1024 --num=100000000 --db=/media/test &> 1.txt

