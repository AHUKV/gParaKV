/home/ubuntu/CLionProjects/unikv-master/out-static/db_bench --benchmarks=fillrandom --value_size=262144 --num=390625 --db=/media/test &> 1.txt

