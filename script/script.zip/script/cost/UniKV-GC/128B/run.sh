/home/ubuntu/CLionProjects/unikv-master/out-static/db_bench --benchmarks=fillrandom --value_size=128 --num=800000000 --db=/media/test &> 1.txt

