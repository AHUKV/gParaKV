/home/ubuntu/CLionProjects/unikv-master/out-static/db_bench --benchmarks=fillrandom --value_size=65536 --num=1562500 --db=/media/test &> 1.txt

