cd 1KB
./gpu_record.sh

cd ..
cd 4KB
./gpu_record.sh

cd ..
cd 64KB
./gpu_record.sh

cd ..
cd 128B
./gpu_record.sh

cd ..
cd 256B
./gpu_record.sh

cd ..
cd 256KB
./gpu_record.sh
